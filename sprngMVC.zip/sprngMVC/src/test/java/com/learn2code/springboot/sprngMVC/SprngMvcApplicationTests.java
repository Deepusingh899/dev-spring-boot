package com.learn2code.springboot.sprngMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprngMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
